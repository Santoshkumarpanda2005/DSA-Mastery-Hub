let activeTabStart = {};

chrome.tabs.onActivated.addListener(async (info) => {
    activeTabStart[info.tabId] = Date.now();
});

chrome.tabs.onRemoved.addListener((tabId) => {
    delete activeTabStart[tabId];
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "problemSolved") {
        console.log("Problem solved data received from content script:", message.data);

        // Send data to backend
        fetch("https://leetcode-tracker-api-h7cp.onrender.com/api/activity", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(message.data)
        })
        .then(response => response.json())
        .then(data => {
            console.log("Successfully sent to backend:", data);
            // Optionally we can send a message back to content script to show a success notification
        })
        .catch(err => {
            console.error("Error sending to backend:", err);
        });
    }
});
